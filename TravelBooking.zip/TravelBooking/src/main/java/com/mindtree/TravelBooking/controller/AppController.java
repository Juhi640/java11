package com.mindtree.TravelBooking.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.TravelBooking.dto.TravelBookingDto;
import com.mindtree.TravelBooking.dto.UserDto;
import com.mindtree.TravelBooking.entity.TravelBooking;
import com.mindtree.TravelBooking.service.UserTravelBookingService;

@Controller
public class AppController {

	@Autowired
	private UserTravelBookingService userTravelBookingService;

	@RequestMapping("/")
	public String login() {
		return "login";
	}

	@RequestMapping("/adduser")
	public String travelpackage() {
		return "addform";
	}

	@PostMapping(value = "/formadd")
	public String addUser(UserDto userDto) {
		userTravelBookingService.registerUserToDB(userDto);
		return "addform";
	}

	@RequestMapping("/addbookingdetails")
	public String travelbooking(Model model) {
		List<UserDto> usersDto = userTravelBookingService.getAllUsers();
		model.addAttribute("usersDto", usersDto);
		return "addform1";
	}

	@PostMapping(value = "/formadd1")
	public String addTravelBooking(TravelBookingDto travelBookingDto, @RequestParam String userName) {
		userTravelBookingService.registerTravelBookingByUser(travelBookingDto, userName);
		return "addform1";
	}

	@RequestMapping("/view")
	public String viewtravelbooking(Model model) {
		List<UserDto> usersDto = userTravelBookingService.getAllUsers();
		model.addAttribute("usersDto", usersDto);
		return "display";
	}

	@GetMapping("/viewtable")
	public String getTravelBooking(@RequestParam String userName, @RequestParam Date date, Model model) {
		UserDto userDto = userTravelBookingService.getAllUsersWithTravelBooking(userName, date);
		model.addAttribute("userDto", userDto);
		return "display";
	}
	
	@GetMapping("/viewtravelbooking/{travelBookingId}")
	public String getTravelBookingByBookingId(@PathVariable int travelBookingId,Model model) {
		TravelBookingDto travelBookingDto=userTravelBookingService.getTravelBooking(travelBookingId);
		model.addAttribute("travelBookingDto", travelBookingDto);
		return "update";
	}
	
	@PostMapping("/updatetable")
		public String updateTravelBooking(@RequestParam  int travelBookingId,@RequestParam String travellingFrom, @RequestParam String travellingTo, @RequestParam int distance)	{
		TravelBooking travelBooking=userTravelBookingService.updateTravelBooking(travelBookingId,travellingFrom, travellingTo, distance);
		return "updaterecord";
	}
	
	

}
