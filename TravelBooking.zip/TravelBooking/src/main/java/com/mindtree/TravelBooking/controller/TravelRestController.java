package com.mindtree.TravelBooking.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.TravelBooking.service.UserTravelBookingService;

@RestController
public class TravelRestController {
	
	private UserTravelBookingService userTravelBookingService;
	
	@GetMapping("/view1/{userName}")
	public List<String> viewtravelbooking(@PathVariable String userName) {
		List<String> source = userTravelBookingService.getAllDetails(userName);
		return source;

	}

}
