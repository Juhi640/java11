package com.mindtree.TravelBooking.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class UserDto {

	private int userId;

	private String userName;
	
	private byte age;

	@JsonIgnoreProperties("user")
	private List<TravelBookingDto> travelBookings;

	public UserDto() {
		super();
	}

	public UserDto(int userId, String userName, List<TravelBookingDto> travelBookings,byte age) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.travelBookings = travelBookings;
		this.age=age;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<TravelBookingDto> getTravelBookings() {
		return travelBookings;
	}

	public void setTravelBookings(List<TravelBookingDto> travelBookings) {
		this.travelBookings = travelBookings;
	}
	

	public byte getAge() {
		return age;
	}

	public void setAge(byte age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "UserDto [userId=" + userId + ", userName=" + userName + ", travelBookings=" + travelBookings + ", age=" + age +"]";
	}

}
