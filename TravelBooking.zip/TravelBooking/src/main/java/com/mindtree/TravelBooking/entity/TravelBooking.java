package com.mindtree.TravelBooking.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class TravelBooking {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int travelBookingId;

	private String travellingFrom;

	private String travellingTo;

	private Date dateOfJoining;

	private int distance;

	private String foodPreference;

	private String travellingWith;

	private int price;

	@ManyToOne(fetch = FetchType.LAZY)
	private User user;

	public TravelBooking() {
		super();
	}

	public TravelBooking(int travelBookingId, String travellingFrom, String travellingTo, Date dateOfJoining,
			int distance, String foodPreference, String travellingWith, int price, User user) {
		super();
		this.travelBookingId = travelBookingId;
		this.travellingFrom = travellingFrom;
		this.travellingTo = travellingTo;
		this.dateOfJoining = dateOfJoining;
		this.distance = distance;
		this.foodPreference = foodPreference;
		this.travellingWith = travellingWith;
		this.price = price;
		this.user = user;
	}

	public int getTravelBookingId() {
		return travelBookingId;
	}

	public void setTravelBookingId(int travelBookingId) {
		this.travelBookingId = travelBookingId;
	}

	public String getTravellingFrom() {
		return travellingFrom;
	}

	public void setTravellingFrom(String travellingFrom) {
		this.travellingFrom = travellingFrom;
	}

	public String getTravellingTo() {
		return travellingTo;
	}

	public void setTravellingTo(String travellingTo) {
		this.travellingTo = travellingTo;
	}

	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

	public String getFoodPreference() {
		return foodPreference;
	}

	public void setFoodPreference(String foodPreference) {
		this.foodPreference = foodPreference;
	}

	public String getTravellingWith() {
		return travellingWith;
	}

	public void setTravellingWith(String travellingWith) {
		this.travellingWith = travellingWith;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "TravelBooking [travelBookingId=" + travelBookingId + ", travellingFrom=" + travellingFrom
				+ ", travellingTo=" + travellingTo + ", dateOfJoining=" + dateOfJoining + ", distance=" + distance
				+ ", foodPreference=" + foodPreference + ", travellingWith=" + travellingWith + ", price=" + price
				+ ", user=" + user + "]";
	}

}
