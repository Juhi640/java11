package com.mindtree.TravelBooking.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;

	private String userName;

	private byte age;

	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	private List<TravelBooking> travelBookings;

	public User() {
		super();
	}

	public User(int userId, String userName, List<TravelBooking> travelBookings, byte age) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.travelBookings = travelBookings;
		this.age = age;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<TravelBooking> getTravelBookings() {
		return travelBookings;
	}

	public void setTravelBookings(List<TravelBooking> travelBookings) {
		this.travelBookings = travelBookings;
	}

	public byte getAge() {
		return age;
	}

	public void setAge(byte age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", age=" + age + ", travelBookings="
				+ travelBookings + "]";
	}

}
