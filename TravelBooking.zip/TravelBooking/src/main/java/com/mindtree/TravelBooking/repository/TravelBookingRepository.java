package com.mindtree.TravelBooking.repository;

import java.util.List;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.mindtree.TravelBooking.entity.TravelBooking;
import com.mindtree.TravelBooking.entity.User;

@Repository
public interface TravelBookingRepository extends JpaRepositoryImplementation<TravelBooking, Integer>{
	
	List<TravelBooking> getBookingByUser(User user);
}
