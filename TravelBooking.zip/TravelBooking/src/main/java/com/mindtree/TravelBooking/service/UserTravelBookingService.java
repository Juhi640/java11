package com.mindtree.TravelBooking.service;

import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.TravelBooking.dto.TravelBookingDto;
import com.mindtree.TravelBooking.dto.UserDto;
import com.mindtree.TravelBooking.entity.TravelBooking;

@Service
public interface UserTravelBookingService {
	
	public UserDto registerUserToDB(UserDto userDto);
	
	public List<UserDto> getAllUsers();
	
	public TravelBookingDto registerTravelBookingByUser(TravelBookingDto travelBookingDto,String userName);
	
	public UserDto getAllUsersWithTravelBooking(String userName,Date date);
	
	public TravelBookingDto getTravelBooking(int travelBookingId);
	
	public TravelBooking updateTravelBooking(int travelBookingId, String travellingFrom, String travellingTo,int distance);

	public List<String> getAllDetails(String userName);
}
