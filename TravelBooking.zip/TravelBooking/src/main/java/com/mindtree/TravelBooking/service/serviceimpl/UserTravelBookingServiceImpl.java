package com.mindtree.TravelBooking.service.serviceimpl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.TravelBooking.dto.TravelBookingDto;
import com.mindtree.TravelBooking.dto.UserDto;
import com.mindtree.TravelBooking.entity.TravelBooking;
import com.mindtree.TravelBooking.entity.User;
import com.mindtree.TravelBooking.repository.TravelBookingRepository;
import com.mindtree.TravelBooking.repository.UserRepository;
import com.mindtree.TravelBooking.service.UserTravelBookingService;

@Service
public class UserTravelBookingServiceImpl implements UserTravelBookingService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private TravelBookingRepository travelBookingRepository;

	@Override
	public UserDto registerUserToDB(UserDto userDto) {
		User user = new User();
		user.setUserId(userDto.getUserId());
		user.setUserName(userDto.getUserName());
		user.setAge(userDto.getAge());
		userRepository.save(user);
		return userDto;
	}

	@Override
	public List<UserDto> getAllUsers() {
		List<User> users = userRepository.findAll();
		List<UserDto> usersDto = new ArrayList<>();
		for (User user : users) {
			UserDto userDto = new UserDto();
			userDto.setUserId(user.getUserId());
			userDto.setUserName(user.getUserName());
			userDto.setAge(user.getAge());
			usersDto.add(userDto);
		}
		return usersDto;
	}

	@Override
	public TravelBookingDto registerTravelBookingByUser(TravelBookingDto travelBookingDto, String userName) {
		User user = userRepository.getByUserName(userName);
		TravelBooking travelBooking = new TravelBooking();
		travelBooking.setTravelBookingId(travelBookingDto.getTravelBookingId());
		travelBooking.setTravellingFrom(travelBookingDto.getTravellingFrom());
		travelBooking.setTravellingTo(travelBookingDto.getTravellingTo());
		travelBooking.setDateOfJoining(travelBookingDto.getDateOfJoining());
		travelBooking.setDistance(travelBookingDto.getDistance());
		travelBooking.setFoodPreference(travelBookingDto.getFoodPreference());
		travelBooking.setTravellingWith(travelBookingDto.getTravellingWith());
		if (user.getAge() > 30 && user.getAge() < 50)
			travelBooking.setPrice(
					(int) ((travelBookingDto.getDistance() * 10) - (.05 * (travelBookingDto.getDistance() * 10))));
		else if (user.getAge() > 50)
			travelBooking.setPrice(
					(int) ((travelBookingDto.getDistance() * 10) - (.1 * (travelBookingDto.getDistance() * 10))));
		else
			travelBooking.setPrice((int) ((travelBookingDto.getDistance() * 10)));
		travelBooking.setUser(user);
		travelBookingRepository.save(travelBooking);
		return travelBookingDto;

	}

	@Override
	public UserDto getAllUsersWithTravelBooking(String userName, Date date) {
		User user = userRepository.getByUserName(userName);
		UserDto userDto = new UserDto();
		List<TravelBookingDto> travelBookingsDto = new ArrayList<>();
		userDto.setUserId(user.getUserId());
		userDto.setUserName(user.getUserName());
		userDto.setAge((byte) user.getAge());
		for (TravelBooking travelBooking : user.getTravelBookings()) {
			if (travelBooking.getDateOfJoining().after(date)) {
				TravelBookingDto travelBookingDto = new TravelBookingDto();
				travelBookingDto.setTravelBookingId(travelBooking.getTravelBookingId());
				travelBookingDto.setTravellingFrom(travelBooking.getTravellingFrom());
				travelBookingDto.setTravellingTo(travelBooking.getTravellingTo());
				travelBookingDto.setDistance(travelBooking.getDistance());
				travelBookingDto.setFoodPreference(travelBooking.getFoodPreference());
				travelBookingDto.setTravellingWith(travelBooking.getTravellingWith());
				travelBookingDto.setPrice(travelBooking.getPrice());
				travelBookingDto.setDateOfJoining(travelBooking.getDateOfJoining());
				travelBookingDto.setUser(userDto);
				travelBookingsDto.add(travelBookingDto);
			}
		}
		userDto.setTravelBookings(travelBookingsDto);
		return userDto;
	}

	@Override
	public TravelBookingDto getTravelBooking(int travelBookingId) {
		TravelBooking travelBooking = travelBookingRepository.findById(travelBookingId).get();
		TravelBookingDto travelBookingDto = new TravelBookingDto();
		travelBookingDto.setTravelBookingId(travelBooking.getTravelBookingId());
		travelBookingDto.setTravellingFrom(travelBooking.getTravellingFrom());
		travelBookingDto.setTravellingTo(travelBooking.getTravellingTo());
		travelBookingDto.setDistance(travelBooking.getDistance());
		travelBookingDto.setFoodPreference(travelBooking.getFoodPreference());
		travelBookingDto.setTravellingWith(travelBooking.getTravellingWith());
		travelBookingDto.setPrice(travelBooking.getPrice());
		travelBookingDto.setDateOfJoining(travelBooking.getDateOfJoining());
		return travelBookingDto;
	}

	/*
	 * @Override public TravelBooking updateTravelBooking(int
	 * travelBookingId,TravelBookingDto travelBookingDto) { TravelBooking
	 * travelBooking =travelBookingRepository.findById(travelBookingId).get();
	 * travelBooking.setTravelBookingId(travelBookingDto.getTravelBookingId());
	 * travelBooking.setTravellingFrom(travelBookingDto.getTravellingFrom());
	 * travelBooking.setTravellingTo(travelBookingDto.getTravellingTo());
	 * travelBooking.setDateOfJoining(travelBookingDto.getDateOfJoining());
	 * travelBooking.setDistance(travelBookingDto.getDistance());
	 * travelBooking.setFoodPreference(travelBookingDto.getFoodPreference());
	 * travelBooking.setTravellingWith(travelBookingDto.getTravellingWith());
	 * if(travelBookingDto.getUser().getAge()>30 &&
	 * travelBookingDto.getUser().getAge()<50) travelBooking.setPrice((int)
	 * ((travelBookingDto.getDistance()*10)-(.05*(travelBookingDto.getDistance()*10)
	 * ))); else if(travelBookingDto.getUser().getAge()>50)
	 * travelBooking.setPrice((int)
	 * ((travelBookingDto.getDistance()*10)-(.1*(travelBookingDto.getDistance()*10))
	 * )); else travelBooking.setPrice((int) ((travelBookingDto.getDistance()*10)));
	 * travelBookingRepository.saveAndFlush(travelBooking); return travelBooking;
	 * 
	 * }
	 */

	@Override
	public TravelBooking updateTravelBooking(int travelBookingId, String travellingFrom, String travellingTo,int distance) {
		TravelBooking travelBooking = travelBookingRepository.findById(travelBookingId).get();
		travelBooking.setTravellingFrom(travellingFrom);
		travelBooking.setTravellingTo(travellingTo);
		travelBooking.setDistance(distance);
		if (travelBooking.getUser().getAge() > 30 && travelBooking.getUser().getAge() < 50)
			travelBooking.setPrice((int) ((distance * 10) - .05 * (distance * 10)));
		else if (travelBooking.getUser().getAge() > 50)
			travelBooking.setPrice((int) ((distance * 10) - .1 * (distance * 10)));
		else
			travelBooking.setPrice((int) ((distance * 10)));
		travelBookingRepository.saveAndFlush(travelBooking);
		return travelBooking;
	}

	@Override
	public List<String> getAllDetails(String userName){
	User user=userRepository.getByUserName(userName);
	List<TravelBooking>travelBookings=travelBookingRepository.getBookingByUser(user);
	List<String> sources=new ArrayList<String>();
	travelBookings.forEach(i->{
		String source=i.getTravellingFrom();
		sources.add(source);
	});
	return sources;

}
}
